'use strict';
var myAppRoot = angular.module('ICWalkApp',[]); 

myAppRoot.controller('reviewController', function($scope,$http) {
//define some object here
        $http.get("palletDetails.json")
    .then(function(response) {
        $scope.productData = response.data;
        angular.forEach($scope.productData,function(value,key){
            if(value.requestId==1){
               $scope.productDto= value;
                console.log($scope.productDto);
            }
        })
        
    });
});



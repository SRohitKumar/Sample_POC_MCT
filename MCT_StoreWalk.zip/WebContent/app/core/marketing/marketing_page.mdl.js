/**
 * 
 */
var marketingPageMdl;
(function(){
marketingPageMdl = angular.module('ssnApp.marketingPageMdl', []);
})();